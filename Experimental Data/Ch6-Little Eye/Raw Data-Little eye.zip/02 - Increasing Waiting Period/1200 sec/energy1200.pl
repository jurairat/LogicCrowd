girl(sara).
girl(lisa).
girl(clare).
%girl(pancake).
%girl(um).
%girl(yaya).
%girl(ploy).
male(justin_bieber).
male(justin_timberlake).
male(ronan_keating).
friend(lisa,clare).
friend(clare,robert).

rest(thai_sontaya).
rest(china_bar).
rest(joawpaya).
rest(la_porchetta).
rest(nando).
rest(lupino).
rest(red_pepper).
rest(bonfire_cafe).
rest(mcdonald).

brand(prada).
brand(gucci).
brand(christian_dior).
brand(chanel).
brand(louis_vuitton).
brand(dkny).
brand(fendi).
brand(armani).

thai(le_bangkok).
thai(baan_thai).
thai(joawpaya).
thai(thai_spicy).
thai(thai_sontaya).
china(china_bar).
italian(la_porchetta).
italian(lupino).
halal(nando).
indian(red_pepper).
indian(bonfire_cafe).
western(medonald).

cbd(le_bangkok).
cbd(china_bar).
cbd(lupino).
cbd(red_pepper).
cbd(bonfire_cafe).
whittlesea(thai_sontaya).
reservior(la_porchetta).
bundoora(nando).
kingsbury(medonald).
melbourne(le_bangkok).
melbourne(baan_thai).
melbourne(thai_sontaya).

delicious(sontaya,whittlesea).
delicious(nandos,kingsbury).

location('satun','m15 melbourn').
location(leegarden,hatyai).

thailand('Wat Arun',bangkok).
thailand('Wat Prakeaw',bangkok).
thailand('Floating Market',bangkok).

thailand('Chinatown (Yaowarat)',bangkok).
thailand('Wat Pho',bangkok).
thailand('Chao Phraya River & Waterways',bangkok).
thailand('Chatuchak Weekend Market',bangkok).
thailand('Khao San Road',bangkok).
thailand('Soi Cowboy',bangkok).
thailand('Jim Thompsons House',bangkok).

/********************************************************************************************/

asksb(X):- X > 0, nice?(Ans)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options([a,b,c]),askto([bluetooth]),expiry('0,0,1200')],
             Y is X-1, asksb(Y).
asksb(0):-true.

asksf(X):- X > 0, findall(B,(thai(B),melbourne(B)),A),
             nice?(Ans)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options(A),askto([facebook]),expiry('0,0,1200')],
             Y is X-1, asksf(Y).
asksf(0):-true.


asksbf(X):- X > 0, findall(B,(thai(B),melbourne(B)),A),
             nice?(Ans)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options(A),askto([bluetooth,facebook]),expiry('0,0,1200')],
             Y is X-1, asksbf(Y).
asksbf(0):-true.



askab(X):-   X > 0,nice?(_)#[asyn,asktype('choice'),question('Which one is your favorite restaurant?'),options([a,b,c]),askto([bluetooth]),expiry('0,0,1200')],
             Y is X-1, askab(Y).
askab(0):-true.


askaf(X):-   X > 0,nice?(_)#[asyn,asktype('choice'),question('Which one is your favorite restaurant?'),options([a,b,c]),askto([facebook]),expiry('0,0,1200')],
             Y is X-1, askaf(Y).
askaf(0):-true.


askabf(X):-   X > 0,nice?(_)#[asyn,asktype('choice'),question('Which one is your favorite restaurant?'),options([a,b,c]),askto([bluetooth,facebook]),expiry('0,0,1200')],
             Y is X-1, askabf(Y).
askabf(0):-true.


asksab(X):- X > 0, findall(B,(thai(B),melbourne(B)),A),
             nice?(Ans)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options(A),askto([bluetooth]),expiry('0,0,1200')],findall(D,male(D),C),handsome?(_)#[asyn,asktype('choice'),question('Vote for the most handsome male singer,Please!'),options(C),askto([bluetooth]),expiry('0,0,1200')],
             Y is X-1, asksab(Y).
asksab(0):-true.

asksaf(X):- X > 0, findall(B,(thai(B),melbourne(B)),A),
             nice?(Ans)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options(A),askto([facebook]),expiry('0,0,1200')],findall(D,male(D),C),handsome?(_)#[asyn,asktype('choice'),question('Vote for the most handsome male singer,Please!'),options(C),askto([facebook]),expiry('0,0,1200')],
             Y is X-1, asksaf(Y).
asksaf(0):-true.

asksabf(X):- X > 0, findall(B,(thai(B),melbourne(B)),A),
             nice?(Ans)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options(A),askto([bluetooth,facebook]),expiry('0,0,1200')],findall(D,male(D),C),handsome?(_)#[asyn,asktype('choice'),question('Vote for the most handsome male singer,Please!'),options(C),askto([bluetooth,facebook]),expiry('0,0,1200')],
             Y is X-1, asksabf(Y).
asksabf(0):-true.








do(X):- X>0, girl(_Y),Z is X-1, do(Z).
do(0).

a(X,Y):- X>0, girl(Y), Z is X-1, a(Z,_Next).
a(0,Y).

does(A,B,X,Y,Z):- girl(X),girl(Y),girl(Z),girl(A),girl(B).



mix(X):- X > 0,
         nice?(ANS)#[syn,asktype('choice'),question('Which one is your favorite restaurant?'),options([a,b,c]),askto([facebook]),expiry('0,0,15')],
		 pretty?(_)#[asyn,asktype('choice'),question('Who is the most beautiful?'),options([sara,may,um]),askto([facebook]),expiry('0,0,15')],
		 Y is X-1, 
		 mix(Y).

mix(0):- true.


/*******************************************************************************************/			


mixb42(X,Y):- findall(B,(thai(B),melbourne(B)),A),nice?(_)#[asyn,asktype('choice'),question('What is favorate restaurant b42?'),options(A),askto([bluetooth]),expiry('0,0,30')],
             findall(V,girl(V),L), pretty?(X)#[syn,asktype('choice'),question('Who is the most beautiful b42?'),options(L),askto([bluetooth]),expiry('0,0,30')],
			 findall(D,male(D),C),handsome?(_)#[asyn,asktype('choice'),question('Vote for the most handsome male singer,Please! b42'),options(C),askto([bluetooth]),expiry('0,0,30')],findall(Z,(thai(Z),melbourne(Z)),F),nice?(Y)#[syn,asktype('choice'),question('Which one is popular restaurant in  melbourne b42?'),options(F),askto([ bluetooth]),expiry('0,0,30')].



handle_crowd_answer(nice,CrowdResult,PopPlace):- quicksort(CrowdResult,'@>',PopPlace).

handle_crowd_answer(handsome,CrowdResult,Handsome):- quicksort(CrowdResult,'@>',Handsome).

handle_crowd_answer(pretty,CrowdResult,Pretty):- quicksort(CrowdResult,'@>',Pretty).

handle_crowd_answer(brand,CrowdResult,Brand):- quicksort(CrowdResult,'@>',Brand).
